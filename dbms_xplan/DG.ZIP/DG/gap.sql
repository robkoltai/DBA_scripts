select * from v$archive_gap;
