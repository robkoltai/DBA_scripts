column name format a6
column open_mode format a12

select name, open_mode, protection_mode, protection_level from v$database;


